
#version 330 core

out vec4 FragColor;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoord;
in vec4 FragPosLightSpace;

uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;
uniform vec3 objectColor;
uniform bool useBlinnPhong;
uniform bool useSmoothShading;
uniform sampler2D brickTexture;
uniform sampler2D shadowMap;
uniform bool useTexture;

// Fungsi Shadow Mapping harus berada di luar main()
float ShadowCalculation(
    vec4 fragPosLightSpace,
    vec3 norm,
    vec3 lightDir
) {
    vec3 projCoords =
        fragPosLightSpace.xyz / fragPosLightSpace.w;

    projCoords = projCoords * 0.5 + 0.5;

    if (projCoords.z > 1.0 ||
        projCoords.x < 0.0 || projCoords.x > 1.0 ||
        projCoords.y < 0.0 || projCoords.y > 1.0) {
        return 0.0;
    }

    float closestDepth =
        texture(shadowMap, projCoords.xy).r;

    float currentDepth = projCoords.z;

    float bias = max(
        0.005 * (1.0 - dot(norm, lightDir)),
        0.001
    );

    return (currentDepth - bias > closestDepth)
        ? 1.0 : 0.0;
}

void main() {
    vec3 norm;

    if (useSmoothShading) {
        norm = normalize(Normal);
    } else {
        norm = normalize(cross(dFdx(FragPos), dFdy(FragPos)));

        if (!gl_FrontFacing) {
            norm = -norm;
        }
    }

    bool isRoof =
        FragPos.y > 0.55 &&
        abs(norm.x) > 0.20 &&
        abs(norm.y) > 0.20;

    vec3 baseColor;

    if (isRoof) {
        baseColor = vec3(0.38, 0.20, 0.10);
    } else {
        baseColor = vec3(0.91, 0.80, 0.61);

        if (abs(norm.y) < 0.20) {
            vec2 wallUV;

            if (abs(norm.x) > abs(norm.z)) {
                wallUV = vec2(FragPos.z, FragPos.y);
            } else {
                wallUV = vec2(FragPos.x, FragPos.y);
            }

            float row = floor(wallUV.y * 3.0);
            float offset = mod(row, 2.0) * 0.5;

            vec2 blockUV = vec2(
                wallUV.x * 2.5 + offset,
                wallUV.y * 3.0
            );

            vec2 cell = fract(blockUV);

            float edgeX = min(cell.x, 1.0 - cell.x);
            float edgeY = min(cell.y, 1.0 - cell.y);
            float edge = min(edgeX, edgeY);

            float mortar = 1.0 - smoothstep(
                0.025, 0.055, edge
            );

            float variation = fract(
                sin(dot(
                    floor(blockUV),
                    vec2(127.1, 311.7)
                )) * 43758.5453
            );

            vec3 creamBrick = mix(
                vec3(0.78, 0.65, 0.43),
                vec3(0.98, 0.88, 0.69),
                variation * 0.45 + 0.45
            );

            vec3 mortarColor = vec3(0.58, 0.46, 0.30);

            baseColor = mix(
                creamBrick,
                mortarColor,
                mortar * 0.55
            );
        }
    }

    // Tekstur bata pada dinding
    if (useTexture && !isRoof && abs(norm.y) < 0.20) {
        baseColor = texture(brickTexture, TexCoord * 4.0).rgb;
    }

    // Pintu
    if (FragPos.z > 0.80 &&
        FragPos.x >= -0.23 && FragPos.x <= 0.23 &&
        FragPos.y <= 0.16) {
        baseColor = vec3(0.28, 0.12, 0.055);
    }

    // Jendela
    if (FragPos.z > 0.80 &&
        FragPos.y >= -0.06 && FragPos.y <= 0.31 &&
        ((FragPos.x >= -0.83 && FragPos.x <= -0.41) ||
         (FragPos.x >= 0.41 && FragPos.x <= 0.83))) {
        baseColor = vec3(0.25, 0.72, 0.85);
    }

    // Pencahayaan ambient
    float ambientStrength = 0.45;
    vec3 ambient = ambientStrength * lightColor;

    vec3 lightDir = normalize(lightPos - FragPos);

    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // Phong dan Blinn-Phong
    vec3 viewDir = normalize(viewPos - FragPos);
    float spec;

    if (useBlinnPhong) {
        vec3 halfwayDir = normalize(lightDir + viewDir);
        spec = pow(max(dot(norm, halfwayDir), 0.0), 8.0);
    } else {
        vec3 reflectDir = reflect(-lightDir, norm);
        spec = pow(max(dot(viewDir, reflectDir), 0.0), 64.0);
    }

    float specularStrength = 0.25;
    vec3 specular = specularStrength * spec * lightColor;

    // Perhitungan bayangan
    float shadow = ShadowCalculation(
        FragPosLightSpace,
        norm,
        lightDir
    );

    vec3 result =
        (ambient + (1.0 - shadow) * diffuse) * baseColor
        + (1.0 - shadow) * specular;

    FragColor = vec4(result, 1.0);
}
