package com.grafkom.viewing3d;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import java.nio.IntBuffer;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryStack.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;

public class ThreeDViewing {

    private long window;
    private int width = 800;
    private int height = 600;

    // Komponen Utama Praktikum
    private Camera3D camera;
    private PerspectiveProjection projection;
    private StereoAnaglyphRenderer stereoRenderer;
    private ProjectionTaxonomyManager.ProjectionType currentProjection = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_1POINT;
    private ShaderProgram shaderProgram;
private CubeMesh cubeMesh;
    // Kontrol Navigasi Kamera Orbital
    private float cameraRadius = 10.0f;
    private float azimuth = 45.0f;
    private float elevation = 30.0f;
    private boolean isStereoEnabled = false;
    private boolean useBlinnPhong = false;
    private boolean useSmoothShading = true;
    private boolean useBackFaceCulling = false;
    private boolean useDepthTest = true;
    private TextureFilterManager textureFilterManager = new TextureFilterManager();
    private int brickTextureId;
    private ShadowMap shadowMap;
    private ShaderProgram shadowShaderProgram;
    


    public void run() {
        init();
        loop();

        glfwFreeCallbacks(window);
        glfwDestroyWindow(window);

        glfwTerminate();
        glfwSetErrorCallback(null).free();
    }

    private void init() {
        GLFWErrorCallback.createPrint(System.err).set();

        if (!glfwInit()) {
            throw new IllegalStateException("Gagal menginisialisasi GLFW.");
        }

        glfwDefaultWindowHints();
glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        window = glfwCreateWindow(width, height, "3D Viewing Interactive Visualizer", NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Gagal membuat jendela GLFW");
        }

        // Listener Keyboard untuk Navigasi Kamera & Switch Proyeksi
        glfwSetKeyCallback(window, (window, key, scancode, action, mods) -> {
            if (action == GLFW_PRESS || action == GLFW_REPEAT) {
                switch (key) {
                    case GLFW_KEY_ESCAPE -> glfwSetWindowShouldClose(window, true);
                    
                    // Kontrol Kamera Orbital
                    case GLFW_KEY_LEFT -> azimuth -= 3.0f;
                    case GLFW_KEY_RIGHT -> azimuth += 3.0f;
                    case GLFW_KEY_UP -> elevation = Math.min(89.0f, elevation + 3.0f);
                    case GLFW_KEY_DOWN -> elevation = Math.max(-89.0f, elevation - 3.0f);
                    case GLFW_KEY_W -> cameraRadius = Math.max(2.0f, cameraRadius - 0.5f);
                    case GLFW_KEY_S -> cameraRadius += 0.5f;

                    // Toggle Stereo Anaglyph
                    case GLFW_KEY_M -> isStereoEnabled = !isStereoEnabled;
                    case GLFW_KEY_B -> useBlinnPhong = !useBlinnPhong;
                    case GLFW_KEY_F -> {
    useSmoothShading = !useSmoothShading;
    System.out.println(
        "Smooth Shading: " +
        (useSmoothShading ? "AKTIF" : "NONAKTIF")
    );
}
                   case GLFW_KEY_C -> {
    useBackFaceCulling = !useBackFaceCulling;

    if (useBackFaceCulling) {
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);
    } else {
        glDisable(GL_CULL_FACE);
    }

    System.out.println(
        "Back-Face Culling: " +
        (useBackFaceCulling ? "AKTIF" : "NONAKTIF")
    );
}
                    case GLFW_KEY_Z -> {
    useDepthTest = !useDepthTest;

    if (useDepthTest) {
        glEnable(GL_DEPTH_TEST);
    } else {
        glDisable(GL_DEPTH_TEST);
    }

    System.out.println(
        "Z-Buffer Depth Test: " +
        (useDepthTest ? "AKTIF" : "NONAKTIF")
    );
}
                    case GLFW_KEY_T -> {
    textureFilterManager.toggleFilter();
}

                    // Switch Taksonomi Proyeksi (Angka 1 - 6)
                    case GLFW_KEY_1 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.ORTHOGRAPHIC;
                    case GLFW_KEY_2 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.ISOMETRIC;
                    case GLFW_KEY_3 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.OBLIQUE_CAVALIER;
                    case GLFW_KEY_4 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_1POINT;
                    case GLFW_KEY_5 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_2POINT;
                    case GLFW_KEY_6 -> currentProjection = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_3POINT;
                }
            }
        });

        // Listener Resize Window
        glfwSetFramebufferSizeCallback(window, (win, w, h) -> {
            this.width = w;
            this.height = h;
            glViewport(0, 0, w, h);
        });

        try (MemoryStack stack = stackPush()) {
            IntBuffer pWidth = stack.mallocInt(1);
            IntBuffer pHeight = stack.mallocInt(1);
            glfwGetWindowSize(window, pWidth, pHeight);
            GLFWVidMode vidmode = glfwGetVideoMode(glfwGetPrimaryMonitor());
            glfwSetWindowPos(
                window,
                (vidmode.width() - pWidth.get(0)) / 2,
                (vidmode.height() - pHeight.get(0)) / 2
            );
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1); // Enable v-sync
        glfwShowWindow(window);

        GL.createCapabilities();
        shadowMap = new ShadowMap();
        glViewport(0, 0, width, height);
        glEnable(GL_DEPTH_TEST);
        glFrontFace(GL_CCW);
        brickTextureId = ProceduralTexture.createBrickTexture();
        
        // Pengaturan Texture Filtering
        System.out.println("Texture Filtering: siap dikonfigurasi");


        // Inisialisasi Objek Praktikum
        camera = new Camera3D(new Vector3f(0, 0, 10), new Vector3f(0, 0, 0), new Vector3f(0, 1, 0));
        projection = new PerspectiveProjection(45.0f, (float) width / height, 0.1f, 100.0f);
        stereoRenderer = new StereoAnaglyphRenderer();
        try {
    shaderProgram = new ShaderProgram(
        "src/main/resources/shaders/phong.vert",
        "src/main/resources/shaders/phong.frag"
    );
     shadowShaderProgram = new ShaderProgram(
        "src/main/resources/shaders/shadow.vert",
        "src/main/resources/shaders/shadow.frag"
    );

    cubeMesh = new CubeMesh();

} catch (java.io.IOException e) {
    throw new RuntimeException("Gagal memuat file shader.", e);
}
    }

    private void loop() {
    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        camera.updateOrbitalPosition(cameraRadius, azimuth, elevation);

        float aspect = (float) width / height;

        // Render kubus dalam mode normal
        renderScene();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
}

    // Fungsi Penggambar Objek 3D (Cube)
    
private void renderScene() {
    if (shaderProgram == null || cubeMesh == null) {
    System.out.println("Shader atau CubeMesh masih null!");
    return;
}

System.out.println("Shader dan CubeMesh berhasil dibuat!");

    shaderProgram.use();

GL13.glActiveTexture(GL13.GL_TEXTURE0);

// Atur filter tekstur terlebih dahulu
textureFilterManager.applyFilter(brickTextureId);

// Pasang kembali tekstur untuk proses rendering
glBindTexture(GL_TEXTURE_2D, brickTextureId);

    if (useBackFaceCulling) {
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
} else {
    glDisable(GL_CULL_FACE);
}
    int program = shaderProgram.getProgramId();

    Matrix4f model = new Matrix4f();
    Matrix4f view = camera.calculateLookAtMatrix();

    Matrix4f proj = new Matrix4f().perspective(
        (float) Math.toRadians(45.0f),
        (float) width / height,
        0.1f,
        100.0f
    );
    
    Matrix4f lightProjection = new Matrix4f().ortho(
        -5.0f, 5.0f,
        -5.0f, 5.0f,
        1.0f, 20.0f
    );

    Matrix4f lightView = new Matrix4f().lookAt(
        new Vector3f(3.0f, 6.0f, 3.0f),
        new Vector3f(0.0f, 0.0f, 0.0f),
        new Vector3f(0.0f, 1.0f, 0.0f)
    );

    Matrix4f lightSpaceMatrix = lightProjection.mul(
        lightView, new Matrix4f()
    );


    try (org.lwjgl.system.MemoryStack stack =
         org.lwjgl.system.MemoryStack.stackPush()) {

    java.nio.FloatBuffer buffer = stack.mallocFloat(16);

    model.get(buffer);
    GL20.glUniformMatrix4fv(
        GL20.glGetUniformLocation(program, "model"),
        false, buffer
    );

    buffer.clear();
    view.get(buffer);
    GL20.glUniformMatrix4fv(
        GL20.glGetUniformLocation(program, "view"),
        false, buffer
    );

    buffer.clear();
    proj.get(buffer);
    GL20.glUniformMatrix4fv(
        GL20.glGetUniformLocation(program, "projection"),
        false, buffer
    );

    buffer.clear();
    lightSpaceMatrix.get(buffer);
    GL20.glUniformMatrix4fv(
        GL20.glGetUniformLocation(program, "lightSpaceMatrix"),
        false, buffer
    );


    GL20.glUniform3f(
        GL20.glGetUniformLocation(program, "lightPos"),
        3.0f, 3.0f, 3.0f
    );
    GL20.glUniform3f(
        GL20.glGetUniformLocation(program, "viewPos"),
        0.0f, 0.0f, 10.0f
    );
    GL20.glUniform3f(
        GL20.glGetUniformLocation(program, "lightColor"),
        1.0f, 1.0f, 1.0f
    );
    GL20.glUniform3f(
        GL20.glGetUniformLocation(program, "objectColor"),
        0.2f, 0.6f, 1.0f
    );
    GL20.glUniform1i(
    GL20.glGetUniformLocation(program, "useBlinnPhong"),
    useBlinnPhong ? 1 : 0
);
    GL20.glUniform1i(
    GL20.glGetUniformLocation(program, "useSmoothShading"),
    useSmoothShading ? 1 : 0
);
    GL20.glUniform1i(
    GL20.glGetUniformLocation(program, "brickTexture"),
    0
);

GL20.glUniform1i(
    GL20.glGetUniformLocation(program, "useTexture"),
    1
);

        cubeMesh.render();
    }

    GL20.glUseProgram(0);
}

    public static void main(String[] args) {
        new ThreeDViewing().run();
    }
}