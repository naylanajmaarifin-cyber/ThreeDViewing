package com.grafkom.viewing3d;

import static org.lwjgl.opengl.GL11.*;

public class ProjectionTaxonomyManager {
    // 6 Jenis Proyeksi sesuai Taksonomi (Memenuhi kriteria >= 5 jenis)
    public enum ProjectionType {
        ORTHOGRAPHIC, 
        ISOMETRIC, 
        OBLIQUE_CAVALIER, 
        PERSPECTIVE_1POINT,
        PERSPECTIVE_2POINT,
        PERSPECTIVE_3POINT
    }

    public static void applyProjection(ProjectionType type, float aspect) {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        
        switch (type) {
            case ORTHOGRAPHIC:
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 1.0, 20.0);
                break;

            case ISOMETRIC:
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 1.0, 20.0);
                glRotatef(35.264f, 1.0f, 0.0f, 0.0f);
                glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
                break;

            case OBLIQUE_CAVALIER:
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 1.0, 20.0);
                float[] shearMatrix = {
                    1, 0, 0, 0,
                    0, 1, 0, 0,
                    (float)Math.cos(Math.toRadians(45)), (float)Math.sin(Math.toRadians(45)), 1, 0,
                    0, 0, 0, 1
                };
                glMultMatrixf(shearMatrix);
                break;

            case PERSPECTIVE_1POINT:
                applyPerspectiveMatrix(45.0f, aspect, 0.1f, 100.0f);
                break;

            case PERSPECTIVE_2POINT:
                applyPerspectiveMatrix(45.0f, aspect, 0.1f, 100.0f);
                glRotatef(30.0f, 0.0f, 1.0f, 0.0f); // Rotasi Y untuk 2 titik hilang
                break;

            case PERSPECTIVE_3POINT:
                applyPerspectiveMatrix(45.0f, aspect, 0.1f, 100.0f);
                glRotatef(30.0f, 0.0f, 1.0f, 0.0f); // Rotasi Y
                glRotatef(15.0f, 1.0f, 0.0f, 0.0f); // Rotasi X untuk 3 titik hilang
                break;
        }
    }

    private static void applyPerspectiveMatrix(float fovDeg, float aspect, float zNear, float zFar) {
        float f = (float)(1.0 / Math.tan(Math.toRadians(fovDeg) / 2.0));
        float[] m = {
            f / aspect, 0, 0, 0,
            0, f, 0, 0,
            0, 0, -(zFar + zNear) / (zFar - zNear), -1,
            0, 0, -(2.0f * zFar * zNear) / (zFar - zNear), 0
        };
        glLoadMatrixf(m);
    }
}