
#version 330 core

void main() {
    // Kedalaman permukaan disimpan otomatis ke depth buffer.
}

