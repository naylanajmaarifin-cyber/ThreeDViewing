
package com.grafkom.viewing3d;

import static org.lwjgl.opengl.GL11.*;

public class TextureFilterManager {

    public enum FilterMode {
        NEAREST,
        LINEAR
    }

    private FilterMode currentMode = FilterMode.NEAREST;

    public void toggleFilter() {
        if (currentMode == FilterMode.NEAREST) {
            currentMode = FilterMode.LINEAR;
        } else {
            currentMode = FilterMode.NEAREST;
        }

        System.out.println("Texture Filtering: " + currentMode);
    }

    public FilterMode getCurrentMode() {
        return currentMode;
    }

    public void applyFilter(int textureId) {
        glBindTexture(GL_TEXTURE_2D, textureId);

        int filter = (currentMode == FilterMode.NEAREST)
                ? GL_NEAREST
                : GL_LINEAR;

        glTexParameteri(
                GL_TEXTURE_2D,
                GL_TEXTURE_MIN_FILTER,
                filter
        );

        glTexParameteri(
                GL_TEXTURE_2D,
                GL_TEXTURE_MAG_FILTER,
                filter
        );

        glBindTexture(GL_TEXTURE_2D, 0);
    }
}
