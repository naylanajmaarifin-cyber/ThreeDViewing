
package com.grafkom.viewing3d;

import java.nio.ByteBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE;
import static org.lwjgl.opengl.GL30.glGenerateMipmap;
import static org.lwjgl.system.MemoryUtil.memAlloc;
import static org.lwjgl.system.MemoryUtil.memFree;

public class ProceduralTexture {

    public static int createBrickTexture() {
        int width = 128;
        int height = 128;

        ByteBuffer pixels = memAlloc(width * height * 4);

        try {
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int row = y / 16;
                    int offset = (row % 2) * 16;

                    int localX = (x + offset) % 32;
                    int localY = y % 16;

                    boolean mortar =
                            localX < 2 ||
                            localY < 2;

                    int red;
                    int green;
                    int blue;

                    if (mortar) {
                        red = 148;
                        green = 117;
                        blue = 77;
                    } else {
                        red = 224;
                        green = 194;
                        blue = 145;
                    }

                    pixels.put((byte) red);
                    pixels.put((byte) green);
                    pixels.put((byte) blue);
                    pixels.put((byte) 255);
                }
            }

            pixels.flip();

            int textureId = glGenTextures();
            glBindTexture(GL_TEXTURE_2D, textureId);

            glTexImage2D(
                    GL_TEXTURE_2D,
                    0,
                    GL_RGBA8,
                    width,
                    height,
                    0,
                    GL_RGBA,
                    GL_UNSIGNED_BYTE,
                    pixels
            );

            glGenerateMipmap(GL_TEXTURE_2D);

            glTexParameteri(
                    GL_TEXTURE_2D,
                    GL_TEXTURE_WRAP_S,
                    GL_REPEAT
            );

            glTexParameteri(
                    GL_TEXTURE_2D,
                    GL_TEXTURE_WRAP_T,
                    GL_REPEAT
            );

            glBindTexture(GL_TEXTURE_2D, 0);

            return textureId;

        } finally {
            memFree(pixels);
        }
    }
}
