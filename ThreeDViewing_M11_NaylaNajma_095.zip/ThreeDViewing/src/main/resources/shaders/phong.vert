
#version 330 core

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoord;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 lightSpaceMatrix;
out vec4 FragPosLightSpace;
uniform bool useSmoothShading;

void main() {
    vec4 worldPosition = model * vec4(aPos, 1.0);

    FragPos = worldPosition.xyz;
    TexCoord = aTexCoord;

    mat3 normalMatrix = mat3(transpose(inverse(model)));

    if (useSmoothShading) {
        Normal = normalize(normalMatrix * normalize(aPos));
    } else {
        Normal = normalize(normalMatrix * aNormal);
    }

    gl_Position = projection * view * worldPosition;
    FragPosLightSpace = lightSpaceMatrix * worldPosition;
}
