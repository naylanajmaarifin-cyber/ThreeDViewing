
package com.grafkom.viewing3d;

import org.lwjgl.opengl.GL20;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class ShaderProgram {

    private final int programId;

    public ShaderProgram(String vertexPath, String fragmentPath)
            throws IOException {

        String vertexSource = Files.readString(
            Path.of(vertexPath), StandardCharsets.UTF_8
        );

        String fragmentSource = Files.readString(
            Path.of(fragmentPath), StandardCharsets.UTF_8
        );

        int vertexShader = compileShader(
            GL20.GL_VERTEX_SHADER, vertexSource
        );

        int fragmentShader = compileShader(
            GL20.GL_FRAGMENT_SHADER, fragmentSource
        );

        programId = GL20.glCreateProgram();

        GL20.glAttachShader(programId, vertexShader);
        GL20.glAttachShader(programId, fragmentShader);
        GL20.glLinkProgram(programId);

        if (GL20.glGetProgrami(
                programId, GL20.GL_LINK_STATUS) == GL20.GL_FALSE) {
            String log = GL20.glGetProgramInfoLog(programId);
            GL20.glDeleteProgram(programId);
            throw new IllegalStateException(
                "Gagal menghubungkan shader:\n" + log
            );
        }

        GL20.glDeleteShader(vertexShader);
        GL20.glDeleteShader(fragmentShader);
    }

    private int compileShader(int type, String source) {
        int shader = GL20.glCreateShader(type);

        GL20.glShaderSource(shader, source);
        GL20.glCompileShader(shader);

        if (GL20.glGetShaderi(
                shader, GL20.GL_COMPILE_STATUS) == GL20.GL_FALSE) {
            String log = GL20.glGetShaderInfoLog(shader);
            GL20.glDeleteShader(shader);
            throw new IllegalStateException(
                "Gagal mengompilasi shader:\n" + log
            );
        }

        return shader;
    }

    public void use() {
        GL20.glUseProgram(programId);
    }

    public int getProgramId() {
        return programId;
    }

    public void cleanup() {
        GL20.glDeleteProgram(programId);
    }
}
