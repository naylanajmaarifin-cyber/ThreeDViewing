
package com.grafkom.viewing3d;

import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import java.util.ArrayList;
import java.util.List;

public class CubeMesh {

    private final int vao;
    private final int vbo;
    private final int vertexCount;

    private final List<Float> vertices = new ArrayList<>();

    public CubeMesh() {
        // Badan rumah
        addBox(
            -1.0f, -0.7f, -0.8f,
             1.0f,  0.6f,  0.8f
        );

        // Atap kiri dan kanan
        float[] frontLeft  = {-1.2f, 0.6f, 0.85f};
        float[] frontRight = { 1.2f, 0.6f, 0.85f};
        float[] frontTop   = { 0.0f, 1.5f, 0.85f};

        float[] backLeft   = {-1.2f, 0.6f, -0.85f};
        float[] backRight  = { 1.2f, 0.6f, -0.85f};
        float[] backTop    = { 0.0f, 1.5f, -0.85f};

        // Bidang atap depan dan belakang
        addTriangle(frontLeft, frontTop, backTop);
        addTriangle(frontLeft, backTop, backLeft);

        addTriangle(frontTop, frontRight, backRight);
        addTriangle(frontTop, backRight, backTop);

        // Segitiga dinding bagian depan dan belakang
        addTriangle(
            new float[]{-1f, 0.6f, 0.87f},
            new float[]{ 1f, 0.6f, 0.87f},
            new float[]{ 0f, 1.35f, 0.87f}
        );

        addTriangle(
            new float[]{ 1f, 0.6f, -0.801f},
            new float[]{-1f, 0.6f, -0.801f},
            new float[]{ 0f, 1.35f, -0.801f}
        );

        // Pintu di bagian depan
        addBox(
            -0.22f, -0.7f, 0.805f,
             0.22f,  0.15f, 0.84f
        );

        // Jendela kiri dan kanan
        addBox(
            -0.82f, -0.05f, 0.805f,
            -0.42f,  0.30f, 0.84f
        );

        addBox(
             0.42f, -0.05f, 0.805f,
             0.82f,  0.30f, 0.84f
        );

        float[] data = new float[vertices.size()];
        for (int i = 0; i < vertices.size(); i++) {
            data[i] = vertices.get(i);
        }

        vertexCount = data.length / 8;

        vao = glGenVertexArrays();
        vbo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, data, GL_STATIC_DRAW);

        // Attribute 0: posisi (x, y, z)
        glVertexAttribPointer(
            0, 3, GL_FLOAT, false, 8 * Float.BYTES, 0
        );
        glEnableVertexAttribArray(0);

        // Attribute 1: normal (nx, ny, nz)
        glVertexAttribPointer(
            1, 3, GL_FLOAT, false,
            8 * Float.BYTES, 3L * Float.BYTES
        );
        glEnableVertexAttribArray(1);

        // Attribute 2: koordinat tekstur (u, v)
        glVertexAttribPointer(
            2, 2, GL_FLOAT, false,
            8 * Float.BYTES, 6L * Float.BYTES
        );
        glEnableVertexAttribArray(2);

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }

    private void addBox(
        float x1, float y1, float z1,
        float x2, float y2, float z2
    ) {
        float[] a = {x1, y1, z2};
        float[] b = {x2, y1, z2};
        float[] c = {x2, y2, z2};
        float[] d = {x1, y2, z2};

        float[] e = {x1, y1, z1};
        float[] f = {x2, y1, z1};
        float[] g = {x2, y2, z1};
        float[] h = {x1, y2, z1};

        
        // Belakang
        addQuad(f, e, h, g);
        // Kiri
        addQuad(e, a, d, h);
        // Kanan
        addQuad(b, f, g, c);
        // Atas
        addQuad(d, c, g, h);
        // Bawah
        addQuad(e, f, b, a);
    }

    private void addQuad(
        float[] a, float[] b, float[] c, float[] d
    ) {
        addTriangle(a, b, c);
        addTriangle(a, c, d);
    }

    private void addTriangle(
        float[] a, float[] b, float[] c
    ) {
        float ux = b[0] - a[0];
        float uy = b[1] - a[1];
        float uz = b[2] - a[2];

        float vx = c[0] - a[0];
        float vy = c[1] - a[1];
        float vz = c[2] - a[2];

        float nx = uy * vz - uz * vy;
        float ny = uz * vx - ux * vz;
        float nz = ux * vy - uy * vx;

        float length = (float) Math.sqrt(
            nx * nx + ny * ny + nz * nz
        );

        if (length > 0f) {
            nx /= length;
            ny /= length;
            nz /= length;
        }

        float[][] points = {a, b, c};

        float[][] uvs = {
            {0f, 0f},
            {1f, 0f},
            {1f, 1f}
        };

        for (int i = 0; i < 3; i++) {
            float[] p = points[i];

            vertices.add(p[0]);
            vertices.add(p[1]);
            vertices.add(p[2]);

            vertices.add(nx);
            vertices.add(ny);
            vertices.add(nz);

            vertices.add(uvs[i][0]);
            vertices.add(uvs[i][1]);
        }
    }

    public void render() {
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, vertexCount);
        glBindVertexArray(0);
    }

    public void cleanup() {
        glDeleteBuffers(vbo);
        glDeleteVertexArrays(vao);
    }
}
